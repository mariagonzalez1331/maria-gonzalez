
package agenda;

/**
 *
 * @author Lola
 */
public class AGENDA {

    public static void main(String[] args) {
       INICIO i = new INICIO();
       i.setVisible(true);
       i.setLocationRelativeTo(null);
    }
    
}
